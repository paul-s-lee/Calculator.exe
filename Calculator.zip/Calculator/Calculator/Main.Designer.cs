﻿namespace Calculator
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.One = new System.Windows.Forms.Button();
            this.Two = new System.Windows.Forms.Button();
            this.Three = new System.Windows.Forms.Button();
            this.Four = new System.Windows.Forms.Button();
            this.Five = new System.Windows.Forms.Button();
            this.Six = new System.Windows.Forms.Button();
            this.Seven = new System.Windows.Forms.Button();
            this.Eight = new System.Windows.Forms.Button();
            this.Nine = new System.Windows.Forms.Button();
            this.Zero = new System.Windows.Forms.Button();
            this.Enter = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Answer = new System.Windows.Forms.RichTextBox();
            this.Plus = new System.Windows.Forms.Button();
            this.Minus = new System.Windows.Forms.Button();
            this.Divide = new System.Windows.Forms.Button();
            this.Multiply = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // One
            // 
            this.One.BackColor = System.Drawing.Color.White;
            this.One.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.One.ForeColor = System.Drawing.Color.Black;
            this.One.Location = new System.Drawing.Point(12, 184);
            this.One.Name = "One";
            this.One.Size = new System.Drawing.Size(50, 50);
            this.One.TabIndex = 0;
            this.One.Text = "1";
            this.One.UseVisualStyleBackColor = false;
            this.One.Click += new System.EventHandler(this.One_Click);
            // 
            // Two
            // 
            this.Two.BackColor = System.Drawing.Color.White;
            this.Two.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Two.ForeColor = System.Drawing.Color.Black;
            this.Two.Location = new System.Drawing.Point(68, 184);
            this.Two.Name = "Two";
            this.Two.Size = new System.Drawing.Size(50, 50);
            this.Two.TabIndex = 1;
            this.Two.Text = "2";
            this.Two.UseVisualStyleBackColor = false;
            this.Two.Click += new System.EventHandler(this.Two_Click);
            // 
            // Three
            // 
            this.Three.BackColor = System.Drawing.Color.White;
            this.Three.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Three.ForeColor = System.Drawing.Color.Black;
            this.Three.Location = new System.Drawing.Point(124, 184);
            this.Three.Name = "Three";
            this.Three.Size = new System.Drawing.Size(50, 50);
            this.Three.TabIndex = 2;
            this.Three.Text = "3";
            this.Three.UseVisualStyleBackColor = false;
            this.Three.Click += new System.EventHandler(this.Three_Click);
            // 
            // Four
            // 
            this.Four.BackColor = System.Drawing.Color.White;
            this.Four.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Four.ForeColor = System.Drawing.Color.Black;
            this.Four.Location = new System.Drawing.Point(12, 128);
            this.Four.Name = "Four";
            this.Four.Size = new System.Drawing.Size(50, 50);
            this.Four.TabIndex = 3;
            this.Four.Text = "4";
            this.Four.UseVisualStyleBackColor = false;
            this.Four.Click += new System.EventHandler(this.Four_Click);
            // 
            // Five
            // 
            this.Five.BackColor = System.Drawing.Color.White;
            this.Five.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Five.ForeColor = System.Drawing.Color.Black;
            this.Five.Location = new System.Drawing.Point(68, 128);
            this.Five.Name = "Five";
            this.Five.Size = new System.Drawing.Size(50, 50);
            this.Five.TabIndex = 4;
            this.Five.Text = "5";
            this.Five.UseVisualStyleBackColor = false;
            this.Five.Click += new System.EventHandler(this.Five_Click);
            // 
            // Six
            // 
            this.Six.BackColor = System.Drawing.Color.White;
            this.Six.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Six.ForeColor = System.Drawing.Color.Black;
            this.Six.Location = new System.Drawing.Point(124, 128);
            this.Six.Name = "Six";
            this.Six.Size = new System.Drawing.Size(50, 50);
            this.Six.TabIndex = 5;
            this.Six.Text = "6";
            this.Six.UseVisualStyleBackColor = false;
            this.Six.Click += new System.EventHandler(this.Six_Click);
            // 
            // Seven
            // 
            this.Seven.BackColor = System.Drawing.Color.White;
            this.Seven.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Seven.ForeColor = System.Drawing.Color.Black;
            this.Seven.Location = new System.Drawing.Point(12, 72);
            this.Seven.Name = "Seven";
            this.Seven.Size = new System.Drawing.Size(50, 50);
            this.Seven.TabIndex = 6;
            this.Seven.Text = "7";
            this.Seven.UseVisualStyleBackColor = false;
            this.Seven.Click += new System.EventHandler(this.Seven_Click);
            // 
            // Eight
            // 
            this.Eight.BackColor = System.Drawing.Color.White;
            this.Eight.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Eight.ForeColor = System.Drawing.Color.Black;
            this.Eight.Location = new System.Drawing.Point(68, 72);
            this.Eight.Name = "Eight";
            this.Eight.Size = new System.Drawing.Size(50, 50);
            this.Eight.TabIndex = 7;
            this.Eight.Text = "8";
            this.Eight.UseVisualStyleBackColor = false;
            this.Eight.Click += new System.EventHandler(this.Eight_Click);
            // 
            // Nine
            // 
            this.Nine.BackColor = System.Drawing.Color.White;
            this.Nine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nine.ForeColor = System.Drawing.Color.Black;
            this.Nine.Location = new System.Drawing.Point(124, 72);
            this.Nine.Name = "Nine";
            this.Nine.Size = new System.Drawing.Size(50, 50);
            this.Nine.TabIndex = 8;
            this.Nine.Text = "9";
            this.Nine.UseVisualStyleBackColor = false;
            this.Nine.Click += new System.EventHandler(this.Nine_Click);
            // 
            // Zero
            // 
            this.Zero.BackColor = System.Drawing.Color.White;
            this.Zero.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Zero.ForeColor = System.Drawing.Color.Black;
            this.Zero.Location = new System.Drawing.Point(68, 240);
            this.Zero.Name = "Zero";
            this.Zero.Size = new System.Drawing.Size(50, 50);
            this.Zero.TabIndex = 9;
            this.Zero.Text = "0";
            this.Zero.UseVisualStyleBackColor = false;
            this.Zero.Click += new System.EventHandler(this.Zero_Click);
            // 
            // Enter
            // 
            this.Enter.BackColor = System.Drawing.Color.White;
            this.Enter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Enter.ForeColor = System.Drawing.Color.Red;
            this.Enter.Location = new System.Drawing.Point(124, 240);
            this.Enter.Name = "Enter";
            this.Enter.Size = new System.Drawing.Size(50, 50);
            this.Enter.TabIndex = 10;
            this.Enter.Text = "Enter";
            this.Enter.UseVisualStyleBackColor = false;
            this.Enter.Click += new System.EventHandler(this.Enter_Click);
            // 
            // Clear
            // 
            this.Clear.BackColor = System.Drawing.Color.White;
            this.Clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Clear.ForeColor = System.Drawing.Color.Cyan;
            this.Clear.Location = new System.Drawing.Point(12, 240);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(50, 50);
            this.Clear.TabIndex = 11;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = false;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Answer
            // 
            this.Answer.BackColor = System.Drawing.Color.White;
            this.Answer.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Answer.ForeColor = System.Drawing.Color.Black;
            this.Answer.Location = new System.Drawing.Point(12, 12);
            this.Answer.Name = "Answer";
            this.Answer.ReadOnly = true;
            this.Answer.Size = new System.Drawing.Size(218, 47);
            this.Answer.TabIndex = 12;
            this.Answer.Text = "";
            this.Answer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Answer_KeyDown);
            // 
            // Plus
            // 
            this.Plus.BackColor = System.Drawing.Color.White;
            this.Plus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Plus.ForeColor = System.Drawing.Color.Black;
            this.Plus.Location = new System.Drawing.Point(180, 128);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(50, 50);
            this.Plus.TabIndex = 13;
            this.Plus.Text = "+";
            this.Plus.UseVisualStyleBackColor = false;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // Minus
            // 
            this.Minus.BackColor = System.Drawing.Color.White;
            this.Minus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minus.ForeColor = System.Drawing.Color.Black;
            this.Minus.Location = new System.Drawing.Point(180, 72);
            this.Minus.Name = "Minus";
            this.Minus.Size = new System.Drawing.Size(50, 50);
            this.Minus.TabIndex = 14;
            this.Minus.Text = "-";
            this.Minus.UseVisualStyleBackColor = false;
            this.Minus.Click += new System.EventHandler(this.Minus_Click);
            // 
            // Divide
            // 
            this.Divide.BackColor = System.Drawing.Color.White;
            this.Divide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Divide.ForeColor = System.Drawing.Color.Black;
            this.Divide.Location = new System.Drawing.Point(180, 184);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(50, 50);
            this.Divide.TabIndex = 15;
            this.Divide.Text = "/";
            this.Divide.UseVisualStyleBackColor = false;
            this.Divide.Click += new System.EventHandler(this.Divide_Click);
            // 
            // Multiply
            // 
            this.Multiply.BackColor = System.Drawing.Color.White;
            this.Multiply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Multiply.ForeColor = System.Drawing.Color.Black;
            this.Multiply.Location = new System.Drawing.Point(180, 242);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(50, 50);
            this.Multiply.TabIndex = 16;
            this.Multiply.Text = "x";
            this.Multiply.UseVisualStyleBackColor = false;
            this.Multiply.Click += new System.EventHandler(this.Multiply_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(48)))));
            this.ClientSize = new System.Drawing.Size(242, 304);
            this.Controls.Add(this.Multiply);
            this.Controls.Add(this.Divide);
            this.Controls.Add(this.Minus);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.Answer);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Enter);
            this.Controls.Add(this.Zero);
            this.Controls.Add(this.Nine);
            this.Controls.Add(this.Eight);
            this.Controls.Add(this.Seven);
            this.Controls.Add(this.Six);
            this.Controls.Add(this.Five);
            this.Controls.Add(this.Four);
            this.Controls.Add(this.Three);
            this.Controls.Add(this.Two);
            this.Controls.Add(this.One);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.KeyPreview = true;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator.exe";
            this.TopMost = true;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button One;
        private System.Windows.Forms.Button Two;
        private System.Windows.Forms.Button Three;
        private System.Windows.Forms.Button Four;
        private System.Windows.Forms.Button Five;
        private System.Windows.Forms.Button Six;
        private System.Windows.Forms.Button Seven;
        private System.Windows.Forms.Button Eight;
        private System.Windows.Forms.Button Nine;
        private System.Windows.Forms.Button Zero;
        private System.Windows.Forms.Button Enter;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.RichTextBox Answer;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button Minus;
        private System.Windows.Forms.Button Divide;
        private System.Windows.Forms.Button Multiply;
    }
}

